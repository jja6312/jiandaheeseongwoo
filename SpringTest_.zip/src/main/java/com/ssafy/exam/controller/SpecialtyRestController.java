package com.ssafy.exam.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.exam.model.dto.Specialty;

@RestController
@RequestMapping("/api/specialty")
public class SpecialtyRestController {
    public ResponseEntity<String> addSpecialty() {
    	return null;
    }

    public ResponseEntity<Specialty> getSpecialty() {
    	return null;
    }

    public ResponseEntity<String> deleteSpecialty() {
    	return null;
    }
}