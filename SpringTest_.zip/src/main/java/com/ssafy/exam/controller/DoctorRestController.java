package com.ssafy.exam.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.exam.model.dto.Doctor;

@RestController
@RequestMapping("/api/doctor")
public class DoctorRestController {

	public ResponseEntity<String> addDoctor() {
		return null;
	}

	public ResponseEntity<List<Doctor>> getAllDoctors() {
		return null;
	}

	public ResponseEntity<Doctor> getDoctorById() {
		return null;
	}

	public ResponseEntity<String> updateDoctor() {
		return null;
	}

	public ResponseEntity<String> deleteDoctor() {
		return null;
	}
}
